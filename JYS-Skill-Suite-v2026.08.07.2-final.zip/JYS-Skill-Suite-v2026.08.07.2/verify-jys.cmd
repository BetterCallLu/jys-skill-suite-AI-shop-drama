@echo off
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\verify.ps1"
set "JYS_EXIT=%ERRORLEVEL%"
echo.
pause
exit /b %JYS_EXIT%

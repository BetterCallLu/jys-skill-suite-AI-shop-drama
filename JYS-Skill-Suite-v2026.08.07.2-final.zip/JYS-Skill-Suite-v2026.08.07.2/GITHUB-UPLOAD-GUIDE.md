# 第一次把 JYS 上传到 GitHub

## 推荐选择

JYS包含你的剧本套路库和产品库，第一次上传建议使用**私有仓库**。私有仓库只有你和被邀请的同事能看到；确认内容可以公开后，再单独讨论开源许可证和公开发布。

## 最简单的方法：GitHub Desktop

1. 在 GitHub 注册账号。
2. 安装 GitHub Desktop，并通过浏览器登录 GitHub.com。
3. 在 GitHub Desktop 选择 **File → Add local repository**。
4. 选择这个完整的 `JYS-Skill-Suite-v2026.08.07.2` 文件夹。
5. 如果界面显示有未提交文件，在左下角 Summary 填 `Initial JYS skill suite`，点击 **Commit to main**。
6. 点击顶部的 **Publish repository**。
7. Repository name 填 `jys-skill-suite`。
8. 保持 **Keep this code private** 勾选，点击 **Publish repository**。

## 邀请同事

进入 GitHub 仓库页面：

1. 点击 **Settings**。
2. 进入 **Collaborators** 或 **Collaborators and teams**。
3. 点击 **Add people**，填写同事的GitHub用户名或邮箱。
4. 同事接受邀请后，即可访问私有仓库。

## 同事安装

同事在仓库页面点击绿色 **Code**，复制HTTPS地址，然后运行：

```cmd
npx skills add 这里粘贴仓库HTTPS地址 --list
npx skills add 这里粘贴仓库HTTPS地址 --skill "*" -a codex -g -y --copy
```

第一条命令必须列出：`jys`、`jys-s1`、`jys-s2`、`jys-s3`、`jys-s4`、`jys-s5`。

如果同事不使用 `npx`，也可以在 GitHub 的 **Code → Download ZIP** 下载，解压后双击 `install-jys.cmd`。

## 以后更新

1. 在本地仓库替换或修改文件。
2. 打开 GitHub Desktop，检查 Changes。
3. 填写更新说明并点击 **Commit to main**。
4. 点击 **Push origin**。
5. 同事重新执行安装命令，或下载新版ZIP重新安装。

## 不要做的事

- 不要只上传 `jys` 而漏掉 `jys-s1` 至 `jys-s5`。
- 不要把 Skill 六个目录拆成六个互不关联的仓库。
- 不要上传项目工作区、客户资料、账号密码、Token或其他私密内容。
- 没确认授权前，不要取消私有仓库选项。

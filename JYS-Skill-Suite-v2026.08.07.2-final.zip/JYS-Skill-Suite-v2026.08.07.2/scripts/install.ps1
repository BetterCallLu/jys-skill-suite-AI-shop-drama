$ErrorActionPreference = "Stop"

$skillNames = @("jys", "jys-s1", "jys-s2", "jys-s3", "jys-s4", "jys-s5")
$packageRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot "..")).Path
$sourceRoot = (Resolve-Path -LiteralPath (Join-Path $packageRoot "skills")).Path
$codexRoot = Join-Path $env:USERPROFILE ".codex"
$targetRoot = Join-Path $codexRoot "skills"
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$documents = [Environment]::GetFolderPath("MyDocuments")
if ([string]::IsNullOrWhiteSpace($documents)) {
    $documents = Join-Path $env:USERPROFILE "Documents"
}
$backupRoot = Join-Path $documents "JYS-skill-backups\$stamp"
$moved = @()
$installed = @()

foreach ($name in $skillNames) {
    $skillFile = Join-Path (Join-Path $sourceRoot $name) "SKILL.md"
    if (-not (Test-Path -LiteralPath $skillFile -PathType Leaf)) {
        throw "Incomplete package: missing $name\SKILL.md"
    }
}

New-Item -ItemType Directory -Path $targetRoot -Force | Out-Null

try {
    foreach ($name in $skillNames) {
        $target = Join-Path $targetRoot $name
        if (Test-Path -LiteralPath $target) {
            New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
            Move-Item -LiteralPath $target -Destination (Join-Path $backupRoot $name)
            $moved += $name
        }
    }

    foreach ($name in $skillNames) {
        Copy-Item -LiteralPath (Join-Path $sourceRoot $name) -Destination (Join-Path $targetRoot $name) -Recurse
        $installed += $name
    }

    foreach ($name in $skillNames) {
        $installedSkill = Join-Path (Join-Path $targetRoot $name) "SKILL.md"
        if (-not (Test-Path -LiteralPath $installedSkill -PathType Leaf)) {
            throw "Install verification failed: $name"
        }
    }
}
catch {
    foreach ($name in $installed) {
        $target = Join-Path $targetRoot $name
        if (Test-Path -LiteralPath $target) {
            Remove-Item -LiteralPath $target -Recurse -Force
        }
    }
    foreach ($name in $moved) {
        $backup = Join-Path $backupRoot $name
        if (Test-Path -LiteralPath $backup) {
            Move-Item -LiteralPath $backup -Destination (Join-Path $targetRoot $name)
        }
    }
    throw
}

Write-Host "All six JYS skills were installed to: $targetRoot" -ForegroundColor Green
if ($moved.Count -gt 0) {
    Write-Host "Previous JYS installation was backed up to: $backupRoot" -ForegroundColor Yellow
}

$python = Get-Command python -ErrorAction SilentlyContinue
if ($python) {
    & $python.Source (Join-Path $targetRoot "jys\scripts\validate_suite.py") $targetRoot
    if ($LASTEXITCODE -ne 0) {
        throw "Files were installed, but suite validation failed. Keep the error output above."
    }
} else {
    Write-Host "Python was not found. Basic file checks passed; run verify-jys.cmd after installing Python." -ForegroundColor Yellow
}

Write-Host "Installation complete. Restart Codex before using JYS." -ForegroundColor Green

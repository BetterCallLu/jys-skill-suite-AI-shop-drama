$ErrorActionPreference = "Stop"

$skillNames = @("jys", "jys-s1", "jys-s2", "jys-s3", "jys-s4", "jys-s5")
$targetRoot = Join-Path (Join-Path $env:USERPROFILE ".codex") "skills"

foreach ($name in $skillNames) {
    $skillFile = Join-Path (Join-Path $targetRoot $name) "SKILL.md"
    if (-not (Test-Path -LiteralPath $skillFile -PathType Leaf)) {
        throw "Missing $name: $skillFile"
    }
}

$versionFile = Join-Path $targetRoot "jys\assets\library-version.json"
if (-not (Test-Path -LiteralPath $versionFile -PathType Leaf)) {
    throw "Missing JYS library version file."
}

$version = (Get-Content -LiteralPath $versionFile -Raw | ConvertFrom-Json).version
$python = Get-Command python -ErrorAction SilentlyContinue
if ($python) {
    & $python.Source (Join-Path $targetRoot "jys\scripts\validate_suite.py") $targetRoot
    if ($LASTEXITCODE -ne 0) {
        throw "JYS suite validation failed."
    }
} else {
    Write-Host "Python was not found. Only the six skills and library version file were checked." -ForegroundColor Yellow
}

Write-Host "JYS installation is complete. Asset version: $version" -ForegroundColor Green
